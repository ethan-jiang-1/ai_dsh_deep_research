---
name: adversarial-review
description: 对抗核查方法论：无来源结论狩猎、证据质量审计、反例覆盖检查、review.md 分级格式与 readiness 判据
---

# adversarial-review — 对抗核查

Critic 的核心方法论。你的产出只有两种价值：找到裂缝（修复它），或证明没有裂缝（PASS）。审查基于**文件实际内容**，逐条对照，不信任何口头保证。

## 三条审查线

### 1. 无来源结论狩猎（CRITICAL 级）

草稿每条关键结论，追 `[来源: evidence/xx.md]` 引用链：

- 引用缺失 → CRITICAL；
- 引用的文件不存在 → CRITICAL；
- 文件存在但没有支持该结论的内容 → CRITICAL（最危险的裂缝：形式合规的伪引用）。

### 2. 证据质量审计（MAJOR 级）

- 支撑关键结论的证据必须 A/B 级；C 级出现于关键位置 → MAJOR；
- quality 分级与来源实际身份不符（转载标 A、论坛标 B）→ MAJOR；
- 交叉验证缺失：关键 claim 无 ≥2 独立来源记录 → MAJOR。

### 3. 反例覆盖检查（MAJOR 级）

- 关键结论没有反例搜索记录（"已搜反例，未见"也算记录）→ MAJOR；
- 矛盾证据被静默忽略（findings 里有 contradicted 但报告没呈现）→ MAJOR；
- 只报喜不报忧的整体倾向 → MAJOR 并点名段落。

## review.md 格式

```
# Review — runs/<slug>（审查对象：<draft 文件>）

## CRITICAL
- C1: <定位：段落/句子> <问题> → <修复建议>
## MAJOR
- M1: ...
## MINOR
- m1: ...

## readiness: PASS | FAIL
判据清单：
- [ ] 关键结论引用链完整且真实
- [ ] 关键结论证据 ≥ A/B 级
- [ ] 关键 claim 均有交叉验证记录
- [ ] 反例覆盖完整
- [ ] 证据缺口如实呈现
```

**PASS 只在零 CRITICAL 且判据全勾时给出**；拿不准的项标出来让主编决定，不要替主编放水。

## 反模式

- 审查变成改稿（你不重写，只定位+建议）；
- 对主编口头补充的"证据"采信（没落盘的不算证据）；
- MINOR 堆积淹没 CRITICAL（按严重度排序，修复优先级天然分明）。
